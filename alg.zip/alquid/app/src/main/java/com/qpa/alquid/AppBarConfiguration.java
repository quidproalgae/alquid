package com.qpa.alquid;

class AppBarConfiguration {
}
