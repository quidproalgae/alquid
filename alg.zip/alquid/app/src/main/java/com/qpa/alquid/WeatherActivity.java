package com.qpa.alquid;

public class WeatherActivity {
}
